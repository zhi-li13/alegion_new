import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject

import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS

import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile

import internal.GlobalVariable as GlobalVariable

import com.kms.katalon.core.annotation.BeforeTestCase
import com.kms.katalon.core.annotation.BeforeTestSuite
import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.annotation.AfterTestSuite
import com.kms.katalon.core.context.TestCaseContext
import com.kms.katalon.core.context.TestSuiteContext
import java.time.Instant
import java.time.format.DateTimeFormatter

import cucumber.api.Scenario
import cucumber.api.java.After
import groovy.time.TimeCategory
import common.newKeyword
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import org.openqa.selenium.WebDriver



class NewTestListener {
	/**
	 * Executes before every test case starts.
	 * @param testCaseContext related information of the executed test case.
	 */

	@BeforeTestSuite
	def createRuntimeGlobalVar() {
	}
	
	@BeforeTestCase
	def getCurrentTestCaseId(TestCaseContext testCaseContext, String dataPath_testCaseID) {
	
		//Get Test Data path and save in Global Variable
		dataPath_testCaseID = testCaseContext.getTestCaseId().replace('Test Cases/', 'Data Files/')
		//dataPath_testCaseID = 'Data Files/01 Batch 1/234052_Verify Reported Oil Value'
		CustomKeywords.'common.newKeyword.addGlobalVariable'('dataFilePath', dataPath_testCaseID)
		
		newKeyword.addGlobalVariable('dataFilePath', dataPath_testCaseID)
		
		println 'Data File path for this Test Case ID is : '+GlobalVariable.dataFilePath
		
		//Get iteration variable and save to Global Variable
		newKeyword.addGlobalVariable('iterationNum', '1')
		KeywordUtil.logInfo('Variable iteration for this Test Case ID is : '+testCaseContext.getTestCaseVariables())
		
		String[] data = testCaseContext.getTestCaseVariables()
		def arrayLength1 = data.length
		println "The arrayLength1 of the array is: " + arrayLength1
		
		if (arrayLength1 > 0) {
			String[] dataIteration = data[0].split('=')
			def arrayLength2 = dataIteration.length
			println "The arrayLength2 of the array is: " + arrayLength2
			
			if (arrayLength2 > 1) {
				CustomKeywords.'common.newKeyword.addGlobalVariable'('iterationNum', dataIteration[1])
			}
		} 
		
		KeywordUtil.logInfo('iteration number for current run is : '+GlobalVariable.iterationNum)
		
		//save Excel Path to Global Variable
		String [] TestCasePath = testCaseContext.getTestCaseId().split('/')
		def arrayLength = TestCasePath.length
		String TestCaseName = TestCasePath[arrayLength-1]
		String TestSuiteName = TestCasePath[arrayLength-2]
		String excelPath = dataPath_testCaseID.replace(TestCaseName,TestSuiteName+'.xlsx')
		
		CustomKeywords.'common.newKeyword.addGlobalVariable'('excelFilePath', excelPath)
		
		//save sheet name to Global Variable
		String[] TestCaseNameArr = TestCaseName.split('_')
		CustomKeywords.'common.newKeyword.addGlobalVariable'('sheetName', TestCaseNameArr[0])
		println 'excelFilePath : '+GlobalVariable.excelFilePath
		println 'sheetName : '+GlobalVariable.sheetName
		
	}
	//aftertestcase for non-BDD
	@AfterTestCase
	def sampleAfterTestCase(TestCaseContext testCaseContext) {
		
		
	 }

	//aftertestsuite
	@AfterTestSuite
	def actionAfterTestSuite() {

		WebUI.closeBrowser()

	}
	
	
}