package common

import static com.kms.katalon.core.testdata.TestDataFactory.findTestData

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.regex.Pattern

import org.apache.commons.lang3.exception.ExceptionUtils
import org.openqa.selenium.By
import org.openqa.selenium.Keys
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement


import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.context.TestCaseContext
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import cucumber.api.Scenario
import cucumber.runtime.ScenarioImpl
import internal.GlobalVariable

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject


import java.text.ParseException


import org.apache.commons.io.FileUtils

import org.openqa.selenium.OutputType
import org.openqa.selenium.TakesScreenshot


import com.kms.katalon.core.testdata.reader.ExcelFactory

import com.kms.katalon.core.webui.common.WebUiCommonHelper




public class newKeyword {

	@Keyword
	def static String getBrowserName(){
		Map map = RunConfiguration.getExecutionProperties()

		if (map.get('drivers').get('system').containsKey('Remote')) {
			// In case remote webdriver
			switch (map.get('drivers').get('preferences').get('Remote').get('browserName').toUpperCase()) {
				case "CHROME":
					return "CHROME"
				case "INTERNET EXPLORER":
					return "IE"
				case "FIREFOX":
					return "FIREFOX"
				//case "Web Services"
				default:
					throw new Exception("Browser name " + map.get('drivers').get('preferences').get('Remote').get('browserName').toUpperCase() + " is not valid")
			}
		} else {
			// in case local webdriver
			switch (DriverFactory.getExecutedBrowser().getName()) {
				case "CHROME_DRIVER":
					return "CHROME"
				case "IE_DRIVER":
					return "IE"
				case "FIREFOX_DRIVER":
					return "FIREFOX"
				default:
					throw new Exception("Browser name " + DriverFactory.getExecutedBrowser().getName() + " is not valid")
			}
		}
	}
	
	@Keyword
	def static String getFileNameWithCurrentTimeSuffix(String name) {
		// Create an instance of SimpleDateFormat used for formatting
		// the string representation of date according to the chosen pattern
		DateFormat df = new SimpleDateFormat("MMddyyyy_HHmmss");

		// Get the today date using Calendar object.
		Date today = Calendar.getInstance().getTime();

		// Using DateFormat format method we can create a string
		// representation of a date with the defined format.
		String todayAsString = df.format(today);

		Pattern p = Pattern.compile('[:"+/]', Pattern.DOTALL | Pattern.CASE_INSENSITIVE);

		return p.matcher(name).replaceAll('-') + '_' + todayAsString + ".png"
	}
	@Keyword
	def static nonBddTestCaseupdate(Scenario scenario, TestCaseContext testCaseContext, long duration){
		String stackTrace = null
		List<String> existedIds = new ArrayList<>()

		String browsername= getBrowserName()
		String testCaseName=testCaseContext.testCaseId
		String testStatus=testCaseContext.testCaseStatus


		if (testStatus.equalsIgnoreCase('failed')) {
			stackTrace=testCaseContext.getMessage()
		}

		def base64Image = newKeyword.takeScreenShot(scenario)
			// Take screenshot when TC is failed
		if (scenario.isFailed()) {
			ScenarioImpl impl = (ScenarioImpl) scenario
			stackTrace = ExceptionUtils.getStackTrace(impl.error)
		}

		// scenario name from excel
		String strTestCaselist=""
		int rowIndex = GlobalVariable.iterationNum.toInteger()
		String DataFilePath = GlobalVariable.dataFilePath
		try {
			strTestCaselist = findTestData(DataFilePath).getValue('ref_testcaseid', rowIndex)
			println(strTestCaselist)
		}
		catch(Exception e) {
			// Do nothing
		}

		if (strTestCaselist == "") {
			return
		}

		for (def id : strTestCaselist.split(";")) {
			// Check if the current tag is in number format or not
			if (!id.trim().isNumber() || existedIds.contains(id.trim())) {
				continue
			}

			// Add the current tag to a list to avoid doing anything to a duplicate one in the future
			existedIds.add(id.trim())
			}

	}
	

	@Keyword
	def static addGlobalVariable(String name, def value) { //void addGlobalVariable(String name, def value) {
		GroovyShell shell1 = new GroovyShell()
		MetaClass mc = shell1.evaluate("internal.GlobalVariable").metaClass
		String getterName = "get" + name.capitalize()
		mc.'static'."$getterName" = { -> return value }
		mc.'static'."$name" = value
	}

	
	
	@Keyword
	/**
	 * Get Test Data for runtime execution Test Cases
	 * */

	def static String getTestData(String columnName){
		String getTestData = findTestData(GlobalVariable.dataFilePath).getValue(columnName, GlobalVariable.iterationNum.toInteger())
		return getTestData
	}
	/**
	 * Take a screenshot when scenario fails
	 * */
	@Keyword
	def static takeScreenShot(Scenario scenario){
		def base64Image
		final String imageName = scenario.getName() + ".png"
		final boolean isFailed = scenario.isFailed()
		if (isFailed) {
			try {
				WebDriver driver = DriverFactory.getWebDriver()
				TakesScreenshot screenshot = (TakesScreenshot) driver
				File src = screenshot.getScreenshotAs(OutputType.FILE)
				base64Image = screenshot.getScreenshotAs(OutputType.BASE64)
				FileUtils.copyFile(src, new File(RunConfiguration.getProjectDir() + "\\Screenshots\\" + imageName))
			} catch (Exception e) {
				println e
			}
		}
		return base64Image
	}


}
