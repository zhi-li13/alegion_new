<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Verify Invalid_negative</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>41703556-f237-405e-86c7-0cafac63ac30</testSuiteGuid>
   <testCaseLink>
      <guid>c1668dff-d051-4eeb-b446-fea4a613ab02</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/01 Alegion/001_Verify Invalid</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>2bcfe8b8-d727-40e7-8f89-15b357cace62</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value>1</value>
         </iterationEntity>
         <testDataId>Data Files/01 Alegion/001_Verify Invalid</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>2bcfe8b8-d727-40e7-8f89-15b357cace62</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>iteration</value>
         <variableId>3e6781dd-9cb4-49cc-ae60-bf387259a4f6</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
