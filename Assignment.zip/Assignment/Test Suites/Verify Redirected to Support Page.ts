<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Verify Redirected to Support Page</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>true</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>3c1276bf-967e-4547-b385-ab0a34582fe6</testSuiteGuid>
   <testCaseLink>
      <guid>0be0c37b-6460-466a-a124-e42607a5a0c4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/01 Alegion/002_Verify Contact Support Page</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>82c53167-5856-47a7-ae96-7fdec3bfebb7</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
